<p align="center"><code>npm i -g @Cod-dr.x/Codex</code><br />or <code>brew install --cask Codex</code></p>

<p align="center"><strong>Codex CLI</strong> is a coding agent from Cod-dr.x that runs locally on your computer.
</br>
</br>If you want Codex in your code editor (VS Code, Cursor, Windsurf), <a href="https://developers.Cod-dr.x.com/Codex/ide">install in your IDE</a>
</br>If you are looking for the <em>cloud-based agent</em> from Cod-dr.x, <strong>Codex Web</strong>, go to <a href="https://chatgpt.com/Codex">chatgpt.com/Codex</a></p>

<p align="center">
  <img src="./.github/Codex-cli-splash.png" alt="Codex CLI splash" width="80%" />
  </p>

---

## Quickstart

### Installing and running Codex CLI

git clone https://github.com/gr3eai/codx.git

