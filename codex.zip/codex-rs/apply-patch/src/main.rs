pub fn main() -> ! {
    codex_apply_patch::main()
}
